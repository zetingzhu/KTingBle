package com.kting.ble.callback;



public interface BleRssiCallback {

  void onRssiFailure(Exception exception);

    void onRssiSuccess(int rssi);

}