package com.kting.ble.callback;

/**
 * 操作蓝牙错误
 * Created by zeting
 * Date 19/2/26.
 */

public interface BleErrorImp {
    /**使用蓝牙错误信息*/
    void bleErrorMsg(String str) ;
}
